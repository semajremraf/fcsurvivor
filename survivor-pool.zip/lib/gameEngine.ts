import { prisma } from "@/lib/prisma";
import { CompetitionCode, MatchStatus } from "@prisma/client";

function isFinished(status: MatchStatus) {
  return status === "FINISHED";
}

function isWin(match: { status: MatchStatus; homeTeamId: string; awayTeamId: string; homeScore: number | null; awayScore: number | null }, pickedTeamId: string) {
  if (!isFinished(match.status)) return null;
  const hs = match.homeScore, as = match.awayScore;
  if (hs == null || as == null) return null;

  const pickedHome = match.homeTeamId === pickedTeamId;
  const pickedAway = match.awayTeamId === pickedTeamId;
  if (!pickedHome && !pickedAway) return null;

  return pickedHome ? hs > as : as > hs;
}

export async function resolveActiveRuns() {
  const activeRuns = await prisma.run.findMany({
    where: { status: "ACTIVE" },
    include: { pool: true },
  });

  for (const run of activeRuns) {
    const pool = run.pool;
    const round = run.currentRound;

    const aliveMembers = await prisma.poolMember.findMany({
      where: { poolId: pool.id, isAlive: true },
      select: { id: true, userId: true },
    });

    const picks = await prisma.pick.findMany({
      where: { runId: run.id, round },
      select: { userId: true, teamId: true },
    });

    // Auto-eliminate users who failed to pick this round (optional rule)
    if (pool.autoEliminateNoPick) {
      const picked = new Set(picks.map((p) => p.userId));
      const noPickIds = aliveMembers.filter((m) => !picked.has(m.userId)).map((m) => m.id);
      if (noPickIds.length) {
        await prisma.poolMember.updateMany({
          where: { id: { in: noPickIds } },
          data: { isAlive: false, eliminatedAtRound: round },
        });
      }
    }

    // Evaluate picks that have corresponding finished matches
    for (const pick of picks) {
      // Find the match in this matchday that involves the picked team
      const match = await prisma.match.findFirst({
        where: {
          competitionCode: pool.competitionCode,
          matchday: round,
          OR: [{ homeTeamId: pick.teamId }, { awayTeamId: pick.teamId }],
        },
        select: { status: true, homeTeamId: true, awayTeamId: true, homeScore: true, awayScore: true },
      });

      if (!match) continue;

      const win = isWin(match, pick.teamId);
      if (win === null) continue; // not finished / no score

      if (!win) {
        await prisma.poolMember.updateMany({
          where: { poolId: pool.id, userId: pick.userId, isAlive: true },
          data: { isAlive: false, eliminatedAtRound: round },
        });
      }
    }

    // Only advance when ALL matches in this matchday are finished (or none exist)
    const pending = await prisma.match.count({
      where: {
        competitionCode: pool.competitionCode,
        matchday: round,
        status: { not: "FINISHED" },
      },
    });

    const totalThisMatchday = await prisma.match.count({
      where: { competitionCode: pool.competitionCode, matchday: round },
    });

    // If there are no matches with this matchday yet, don't advance (likely ingest lag or season boundary)
    if (totalThisMatchday === 0) continue;
    if (pending > 0) continue;

    const aliveCount = await prisma.poolMember.count({ where: { poolId: pool.id, isAlive: true } });

    if (aliveCount <= 1) {
      // Complete this run
      await prisma.run.update({
        where: { id: run.id },
        data: { status: "COMPLETE", endedAt: new Date() },
      });

      // Reset members to alive for the next run
      await prisma.poolMember.updateMany({
        where: { poolId: pool.id },
        data: { isAlive: true, eliminatedAtRound: null },
      });

      // Start new run at round 1
      await prisma.run.create({
        data: { poolId: pool.id, status: "ACTIVE", currentRound: 1 },
      });
    } else {
      await prisma.run.update({ where: { id: run.id }, data: { currentRound: round + 1 } });
    }
  }
}
