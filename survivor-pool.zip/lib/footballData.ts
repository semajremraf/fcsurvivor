const BASE = "https://api.football-data.org/v4";

export type CompetitionCode = "PL" | "ELC" | "EL1";

export async function fdGet(path: string) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "X-Auth-Token": process.env.FOOTBALL_DATA_TOKEN! },
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`football-data error ${res.status}: ${await res.text()}`);
  return res.json();
}

export async function fetchCompetitionTeams(code: CompetitionCode, seasonYear?: number) {
  const qs = seasonYear ? `?season=${seasonYear}` : "";
  return fdGet(`/competitions/${code}/teams${qs}`);
}

export async function fetchCompetitionMatches(code: CompetitionCode, seasonYear?: number) {
  const qs = seasonYear ? `?season=${seasonYear}` : "";
  return fdGet(`/competitions/${code}/matches${qs}`);
}
