"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";

type Pool = {
  id: string;
  name: string;
  joinCode: string;
  competitionCode: "PL" | "ELC" | "EL1";
  runs: { id: string; currentRound: number }[];
  members: { isAlive: boolean }[];
};

export default function DashboardClient() {
  const [pools, setPools] = useState<Pool[]>([]);
  const [err, setErr] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [competitionCode, setCompetitionCode] = useState<Pool["competitionCode"]>("PL");
  const [joinCode, setJoinCode] = useState("");

  const aliveSummary = (p: Pool) => {
    const alive = p.members.filter(m => m.isAlive).length;
    return `${alive}/${p.members.length} alive`;
  };

  async function refresh() {
    setErr(null);
    const res = await fetch("/api/pools", { cache: "no-store" });
    const data = await res.json();
    if (!res.ok) { setErr(data.error ?? "Failed to load pools"); return; }
    setPools(data.pools ?? []);
  }

  useEffect(() => { refresh(); }, []);

  async function createPool() {
    setErr(null);
    const res = await fetch("/api/pools", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, competitionCode }),
    });
    const data = await res.json();
    if (!res.ok) { setErr(data.error ?? "Failed to create pool"); return; }
    setName("");
    await refresh();
  }

  async function joinPool() {
    setErr(null);
    const res = await fetch("/api/pools/join", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ joinCode }),
    });
    const data = await res.json();
    if (!res.ok) { setErr(data.error ?? "Failed to join"); return; }
    setJoinCode("");
    await refresh();
    if (data.poolId) window.location.href = `/pool/${data.poolId}`;
  }

  const sorted = useMemo(() => pools.slice(), [pools]);

  return (
    <>
      {err ? <div className="card"><strong>Error:</strong> {err}</div> : null}

      <div className="card">
        <h3>Create a pool</h3>
        <div className="row">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Pool name" />
          <select value={competitionCode} onChange={(e) => setCompetitionCode(e.target.value as any)}>
            <option value="PL">Premier League</option>
            <option value="ELC">Championship</option>
            <option value="EL1">League One</option>
          </select>
          <button onClick={createPool} disabled={!name.trim()}>Create</button>
        </div>
        <small>Note: MVP pools are single-competition. (We can add combined leagues as a next step.)</small>
      </div>

      <div className="card">
        <h3>Join a pool</h3>
        <div className="row">
          <input value={joinCode} onChange={(e) => setJoinCode(e.target.value.toUpperCase())} placeholder="Join code" />
          <button onClick={joinPool} disabled={!joinCode.trim()}>Join</button>
        </div>
      </div>

      <div className="card">
        <h3>Your pools</h3>
        {sorted.length === 0 ? <small>No pools yet.</small> : null}
        {sorted.map((p) => (
          <div key={p.id} className="card">
            <div className="row" style={{ justifyContent: "space-between" }}>
              <div>
                <div><strong>{p.name}</strong> <small>({p.competitionCode})</small></div>
                <small>Join code: <code>{p.joinCode}</code> • {aliveSummary(p)} • Round {p.runs?.[0]?.currentRound ?? 1}</small>
              </div>
              <Link href={`/pool/${p.id}`}>Open →</Link>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
