"use client";

import { signIn, signOut } from "next-auth/react";

export default function SignInOut({ sessionEmail }: { sessionEmail: string | null }) {
  return (
    <div className="row">
      {sessionEmail ? (
        <>
          <span>Signed in as <strong>{sessionEmail}</strong></span>
          <button onClick={() => signOut()}>Sign out</button>
        </>
      ) : (
        <button onClick={() => signIn("google")}>Sign in with Google</button>
      )}
    </div>
  );
}
