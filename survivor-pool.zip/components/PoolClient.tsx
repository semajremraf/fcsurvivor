"use client";

import { useEffect, useMemo, useState } from "react";

type Team = { id: string; name: string; shortName: string | null; crestUrl: string | null };
type Status = {
  pool: { id: string; name: string; joinCode: string; competitionCode: "PL" | "ELC" | "EL1" };
  run: { id: string; currentRound: number; status: string };
  member: { isAlive: boolean; eliminatedAtRound: number | null };
  teams: Team[];
  myPick: { teamId: string } | null;
};

export default function PoolClient({ poolId }: { poolId: string }) {
  const [status, setStatus] = useState<Status | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [teamId, setTeamId] = useState<string>("");

  async function refresh() {
    setErr(null);
    const res = await fetch(`/api/pools/${poolId}/status`, { cache: "no-store" });
    const data = await res.json();
    if (!res.ok) { setErr(data.error ?? "Failed to load pool"); return; }
    setStatus(data);
    setTeamId(data.myPick?.teamId ?? "");
  }

  useEffect(() => { refresh(); }, [poolId]);

  const teams = useMemo(() => status?.teams ?? [], [status]);

  async function submitPick() {
    setErr(null);
    const res = await fetch(`/api/pools/${poolId}/pick`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ teamId }),
    });
    const data = await res.json();
    if (!res.ok) { setErr(data.error ?? "Failed to submit pick"); return; }
    await refresh();
  }

  if (!status) return <div className="card">Loading…</div>;

  return (
    <>
      <h1>{status.pool.name}</h1>
      <div className="card">
        <div><small>Join code:</small> <code>{status.pool.joinCode}</code></div>
        <div><small>Competition:</small> {status.pool.competitionCode}</div>
        <div><small>Current round:</small> {status.run.currentRound}</div>
        <div><small>Your status:</small> {status.member.isAlive ? "Alive ✅" : `Out ❌ (eliminated in round ${status.member.eliminatedAtRound})`}</div>
      </div>

      {err ? <div className="card"><strong>Error:</strong> {err}</div> : null}

      <div className="card">
        <h3>Make your pick</h3>
        {!status.member.isAlive ? (
          <small>You&apos;re eliminated this run. The pool will restart automatically when a winner is decided.</small>
        ) : (
          <>
            {teams.length === 0 ? (
              <small>No available teams for this round yet. This usually means matches haven&apos;t been ingested for this matchday.</small>
            ) : (
              <div className="row">
                <select value={teamId} onChange={(e) => setTeamId(e.target.value)}>
                  <option value="">Select a team…</option>
                  {teams.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
                <button onClick={submitPick} disabled={!teamId}>Submit pick</button>
              </div>
            )}
            {status.myPick?.teamId ? <small>Saved pick for this round ✅</small> : <small>No pick saved yet.</small>}
          </>
        )}
      </div>

      <div className="card">
        <h3>Cron endpoints</h3>
        <small>
          If you want to manually trigger ingestion/resolution (for testing), call:
          <ul>
            <li><code>/api/cron/ingest?secret=CRON_SECRET</code></li>
            <li><code>/api/cron/resolve?secret=CRON_SECRET</code></li>
          </ul>
        </small>
      </div>
    </>
  );
}
