# Survivor Pool (Vercel + football-data.org)

MVP web app:
- Google sign-in (NextAuth)
- Create / join pools (single competition per pool: PL, ELC, EL1)
- Import teams + fixtures/results from football-data.org via Vercel Cron
- Pick one team per round (matchday)
- If your team doesn't WIN, you're out
- Runs restart automatically when 0 or 1 players remain

## 1) Prereqs
- football-data.org API token
- Google OAuth credentials (Web application)
- Postgres database (Neon, Supabase, etc.)

## 2) Setup (local)
```bash
cp .env.example .env
npm install
npx prisma migrate dev
npm run dev
```

## 3) Environment variables
Set these in Vercel Project Settings → Environment Variables:
- DATABASE_URL
- NEXTAUTH_URL (your Vercel URL)
- NEXTAUTH_SECRET
- GOOGLE_CLIENT_ID
- GOOGLE_CLIENT_SECRET
- FOOTBALL_DATA_TOKEN
- CRON_SECRET

## 4) Cron jobs
`vercel.json` configures:
- /api/cron/ingest every 30 minutes
- /api/cron/resolve every 15 minutes

### Protecting cron endpoints
Cron endpoints require header `x-cron-secret: $CRON_SECRET`.
For manual testing you can call:
- /api/cron/ingest?secret=CRON_SECRET
- /api/cron/resolve?secret=CRON_SECRET

## 5) Notes / limitations (MVP)
- Pools are single-competition for now (PL, ELC, or EL1). Import still ingests all 3 competitions.
- Pick cutoff is per-team match kickoff time (simple lock). You can enhance to "earliest kickoff in matchday".
- Combined leagues in one pool can be added by defining rounds as time windows.
