import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/authOptions";
import DashboardClient from "@/components/DashboardClient";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) redirect("/");

  return (
    <>
      <h1>Dashboard</h1>
      <p><a href="/">← Home</a></p>
      <DashboardClient />
    </>
  );
}
