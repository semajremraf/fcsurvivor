import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/authOptions";
import PoolClient from "@/components/PoolClient";

export default async function PoolPage({ params }: { params: { poolId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) redirect("/");

  return (
    <>
      <p><a href="/dashboard">← Dashboard</a></p>
      <PoolClient poolId={params.poolId} />
    </>
  );
}
