import { NextResponse } from "next/server";
import { requireCronSecret } from "@/lib/cronAuth";
import { fetchCompetitionMatches, fetchCompetitionTeams } from "@/lib/footballData";
import { prisma } from "@/lib/prisma";
import { CompetitionCode, MatchStatus } from "@prisma/client";

const CODES: CompetitionCode[] = ["PL", "ELC", "EL1"];

function mapStatus(status: string): MatchStatus {
  // football-data returns statuses like SCHEDULED, TIMED, IN_PLAY, PAUSED, FINISHED, POSTPONED, SUSPENDED, CANCELLED
  if (status in MatchStatus) return status as MatchStatus;
  return "SCHEDULED";
}

export async function GET(req: Request) {
  requireCronSecret(req);

  for (const code of CODES) {
    const teams = await fetchCompetitionTeams(code);
    for (const t of teams.teams ?? []) {
      await prisma.team.upsert({
        where: { id: String(t.id) },
        update: {
          name: t.name,
          shortName: t.shortName ?? null,
          crestUrl: t.crest ?? t.crestUrl ?? null,
          competitionCode: code,
        },
        create: {
          id: String(t.id),
          name: t.name,
          shortName: t.shortName ?? null,
          crestUrl: t.crest ?? t.crestUrl ?? null,
          competitionCode: code,
        },
      });
    }

    const matches = await fetchCompetitionMatches(code);
    for (const m of matches.matches ?? []) {
      await prisma.match.upsert({
        where: { id: String(m.id) },
        update: {
          competitionCode: code,
          seasonYear: m.season?.startDate ? new Date(m.season.startDate).getUTCFullYear() : null,
          matchday: m.matchday ?? null,
          utcDate: new Date(m.utcDate),
          status: mapStatus(m.status),
          homeTeamId: String(m.homeTeam?.id),
          awayTeamId: String(m.awayTeam?.id),
          homeScore: m.score?.fullTime?.home ?? null,
          awayScore: m.score?.fullTime?.away ?? null,
        },
        create: {
          id: String(m.id),
          competitionCode: code,
          seasonYear: m.season?.startDate ? new Date(m.season.startDate).getUTCFullYear() : null,
          matchday: m.matchday ?? null,
          utcDate: new Date(m.utcDate),
          status: mapStatus(m.status),
          homeTeamId: String(m.homeTeam?.id),
          awayTeamId: String(m.awayTeam?.id),
          homeScore: m.score?.fullTime?.home ?? null,
          awayScore: m.score?.fullTime?.away ?? null,
        },
      });
    }
  }

  return NextResponse.json({ ok: true });
}
