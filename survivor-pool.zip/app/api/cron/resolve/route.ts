import { NextResponse } from "next/server";
import { requireCronSecret } from "@/lib/cronAuth";
import { resolveActiveRuns } from "@/lib/gameEngine";

export async function GET(req: Request) {
  requireCronSecret(req);
  await resolveActiveRuns();
  return NextResponse.json({ ok: true });
}
