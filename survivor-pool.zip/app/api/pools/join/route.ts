import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const me = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!me) return NextResponse.json({ error: "User not found" }, { status: 404 });

  const body = await req.json().catch(() => ({}));
  const joinCode = String(body.joinCode ?? "").trim().toUpperCase();
  if (!joinCode) return NextResponse.json({ error: "joinCode required" }, { status: 400 });

  const pool = await prisma.pool.findUnique({ where: { joinCode } });
  if (!pool) return NextResponse.json({ error: "Pool not found" }, { status: 404 });

  await prisma.poolMember.upsert({
    where: { poolId_userId: { poolId: pool.id, userId: me.id } },
    update: {},
    create: { poolId: pool.id, userId: me.id },
  });

  return NextResponse.json({ ok: true, poolId: pool.id });
}
