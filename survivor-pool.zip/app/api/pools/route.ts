import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { prisma } from "@/lib/prisma";
import { makeJoinCode } from "@/lib/joinCode";
import { CompetitionCode } from "@prisma/client";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const me = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!me) return NextResponse.json({ error: "User not found" }, { status: 404 });

  const pools = await prisma.pool.findMany({
    where: { members: { some: { userId: me.id } } },
    orderBy: { createdAt: "desc" },
    include: {
      runs: { where: { status: "ACTIVE" }, take: 1, orderBy: { startedAt: "desc" } },
      members: { select: { isAlive: true } },
    },
  });

  return NextResponse.json({ pools });
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const me = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!me) return NextResponse.json({ error: "User not found" }, { status: 404 });

  const body = await req.json().catch(() => ({}));
  const name = String(body.name ?? "").trim();
  const competitionCode = String(body.competitionCode ?? "PL") as CompetitionCode;
  const allowTeamReuse = Boolean(body.allowTeamReuse ?? false);
  const autoEliminateNoPick = Boolean(body.autoEliminateNoPick ?? true);

  if (!name) return NextResponse.json({ error: "Name required" }, { status: 400 });

  // generate join code (retry on collision)
  let joinCode = makeJoinCode();
  for (let i = 0; i < 5; i++) {
    const exists = await prisma.pool.findUnique({ where: { joinCode } });
    if (!exists) break;
    joinCode = makeJoinCode();
  }

  const pool = await prisma.pool.create({
    data: {
      name,
      joinCode,
      ownerId: me.id,
      competitionCode,
      allowTeamReuse,
      autoEliminateNoPick,
      members: { create: { userId: me.id } },
      runs: { create: { status: "ACTIVE", currentRound: 1 } },
    },
  });

  return NextResponse.json({ pool });
}
