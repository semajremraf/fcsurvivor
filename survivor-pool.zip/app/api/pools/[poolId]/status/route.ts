import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { prisma } from "@/lib/prisma";

export async function GET(_: Request, { params }: { params: { poolId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const me = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!me) return NextResponse.json({ error: "User not found" }, { status: 404 });

  const pool = await prisma.pool.findUnique({
    where: { id: params.poolId },
    include: { runs: { where: { status: "ACTIVE" }, take: 1, orderBy: { startedAt: "desc" } } },
  });
  if (!pool) return NextResponse.json({ error: "Pool not found" }, { status: 404 });

  const member = await prisma.poolMember.findUnique({
    where: { poolId_userId: { poolId: pool.id, userId: me.id } },
  });
  if (!member) return NextResponse.json({ error: "Not a member" }, { status: 403 });

  const run = pool.runs[0];
  if (!run) return NextResponse.json({ error: "No active run" }, { status: 500 });

  // Teams available for this round (must have a match in this matchday)
  const matches = await prisma.match.findMany({
    where: { competitionCode: pool.competitionCode, matchday: run.currentRound },
    select: { homeTeamId: true, awayTeamId: true },
  });

  const teamIds = Array.from(new Set(matches.flatMap(m => [m.homeTeamId, m.awayTeamId])));

  // If no reuse, remove already used teams by this user
  let filteredIds = teamIds;
  if (!pool.allowTeamReuse) {
    const used = await prisma.pick.findMany({
      where: { poolId: pool.id, userId: me.id, runId: run.id },
      select: { teamId: true },
    });
    const usedSet = new Set(used.map(u => u.teamId));
    filteredIds = teamIds.filter(id => !usedSet.has(id));
  }

  const teams = await prisma.team.findMany({
    where: { id: { in: filteredIds } },
    orderBy: { name: "asc" },
    select: { id: true, name: true, shortName: true, crestUrl: true },
  });

  const myPick = await prisma.pick.findUnique({
    where: { runId_userId_round: { runId: run.id, userId: me.id, round: run.currentRound } },
  }).catch(async () => {
    // Prisma can't create compound unique alias name automatically here in TS without generated type;
    // fallback to findFirst if the name differs based on prisma version.
    return prisma.pick.findFirst({ where: { runId: run.id, userId: me.id, round: run.currentRound } });
  });

  return NextResponse.json({
    pool: { id: pool.id, name: pool.name, joinCode: pool.joinCode, competitionCode: pool.competitionCode },
    run: { id: run.id, currentRound: run.currentRound, status: run.status },
    member: { isAlive: member.isAlive, eliminatedAtRound: member.eliminatedAtRound },
    teams,
    myPick,
  });
}
