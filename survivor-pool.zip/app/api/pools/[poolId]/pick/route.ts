import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request, { params }: { params: { poolId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const me = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!me) return NextResponse.json({ error: "User not found" }, { status: 404 });

  const pool = await prisma.pool.findUnique({
    where: { id: params.poolId },
    include: { runs: { where: { status: "ACTIVE" }, take: 1, orderBy: { startedAt: "desc" } } },
  });
  if (!pool) return NextResponse.json({ error: "Pool not found" }, { status: 404 });

  const member = await prisma.poolMember.findUnique({
    where: { poolId_userId: { poolId: pool.id, userId: me.id } },
  });
  if (!member) return NextResponse.json({ error: "Not a member" }, { status: 403 });
  if (!member.isAlive) return NextResponse.json({ error: "You are eliminated" }, { status: 400 });

  const run = pool.runs[0];
  if (!run) return NextResponse.json({ error: "No active run" }, { status: 500 });

  const body = await req.json().catch(() => ({}));
  const teamId = String(body.teamId ?? "").trim();
  if (!teamId) return NextResponse.json({ error: "teamId required" }, { status: 400 });

  // Ensure team exists and is in the pool competition
  const team = await prisma.team.findUnique({ where: { id: teamId } });
  if (!team || team.competitionCode !== pool.competitionCode) {
    return NextResponse.json({ error: "Invalid team" }, { status: 400 });
  }

  // Ensure team has a match in the current matchday
  const match = await prisma.match.findFirst({
    where: {
      competitionCode: pool.competitionCode,
      matchday: run.currentRound,
      OR: [{ homeTeamId: teamId }, { awayTeamId: teamId }],
    },
    select: { id: true, utcDate: true, status: true },
  });
  if (!match) return NextResponse.json({ error: "Team has no match this round" }, { status: 400 });

  // Basic cutoff: prevent picking if match already started
  if (new Date(match.utcDate).getTime() <= Date.now()) {
    return NextResponse.json({ error: "Pick locked (match already started)" }, { status: 400 });
  }

  // If no reuse, ensure not used before in this run
  if (!pool.allowTeamReuse) {
    const used = await prisma.pick.findFirst({ where: { runId: run.id, userId: me.id, teamId } });
    if (used) return NextResponse.json({ error: "Team already used in this run" }, { status: 400 });
  }

  // Upsert pick for this round
  const pick = await prisma.pick.upsert({
    where: { runId_userId_round: { runId: run.id, userId: me.id, round: run.currentRound } } as any,
    update: { teamId },
    create: { runId: run.id, poolId: pool.id, userId: me.id, round: run.currentRound, teamId },
  });

  return NextResponse.json({ ok: true, pick });
}
