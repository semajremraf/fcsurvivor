import "./globals.css";
import Providers from "./providers";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Survivor Pool",
  description: "Pick one team each round. If they don't win, you're out.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers><main>{children}</main></Providers>
      </body>
    </html>
  );
}
