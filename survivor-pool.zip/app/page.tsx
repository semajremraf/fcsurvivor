import { getServerSession } from "next-auth";
import Link from "next/link";
import { authOptions } from "@/lib/authOptions";
import SignInOut from "@/components/SignInOut";

export default async function HomePage() {
  const session = await getServerSession(authOptions);

  return (
    <>
      <h1>Survivor Pool</h1>
      <p>Sign in with Google, join or create a pool, and pick one team per round. If your team doesn&apos;t win, you&apos;re out.</p>
      <div className="card">
        <SignInOut sessionEmail={session?.user?.email ?? null} />
        {session?.user?.email ? (
          <p style={{ marginTop: 12 }}>
            <Link href="/dashboard">Go to dashboard →</Link>
          </p>
        ) : (
          <small>Sign in to continue.</small>
        )}
      </div>
      <div className="card">
        <h3>Setup note</h3>
        <small>
          This app relies on football-data.org ingestion via Vercel Cron. After deployment, run the ingest cron once
          (or wait 30 minutes) so teams/matches populate.
        </small>
      </div>
    </>
  );
}
